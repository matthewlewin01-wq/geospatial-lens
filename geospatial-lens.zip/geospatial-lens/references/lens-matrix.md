# Geospatial Lens matrix

The Lens crosses six geospatial contexts with four modes of analysis. Each of
the 24 pairings below defines what that kind of question does. Use it when you
tag a "where" question: pick the pairing whose definition matches what the
question actually asks. If no pairing fits, the question probably isn't a
geography question, or it needs rewording.

## Modes of analysis

- Describe: characterize the situation
- Diagnose: identify the root cause
- Predict: forecast future conditions
- Prescribe: recommend actions

## Location (position or site)

- Describe: Map and compare conditions at specific locations
- Diagnose: Determine why conditions occur or change at specific locations
- Predict: Forecast conditions or model scenarios at specific locations
- Prescribe: Recommend actions based on forecasted conditions at specific locations

## Scale (size or shape)

- Describe: Map and compare the size or shape of features or events
- Diagnose: Determine why features or events are a specific size or shape
- Predict: Forecast how the size or shape of features or events might change
- Prescribe: Recommend actions based on the forecasted size or shape of features or events

## Route (path of travel)

- Describe: Map and compare routes of interest, find the optimal route based on static conditions
- Diagnose: Determine why events occur along a route or why a route changes
- Predict: Forecast how conditions might change along a route, find the optimal route based on changing conditions
- Prescribe: Recommend actions based on forecasted conditions along a route

## Distribution (arrangement in space)

- Describe: Map and compare the clustering or spread of features or events
- Diagnose: Determine the underlying cause of distribution or changes in distribution
- Predict: Forecast the future distribution of features or events
- Prescribe: Recommend actions based on the forecasted distribution of features or events

## Proximity (relative distance)

- Describe: Map and compare what's nearby, far away or within/outside a range
- Diagnose: Determine why features or events are nearby, far away or within/outside a range
- Predict: Forecast how the proximity of features or events to each other might change
- Prescribe: Recommend actions based on the forecasted proximity of features or events

## Correlation (relationship between features or events)

- Describe: Map and compare how conditions in one area correspond to conditions in another area
- Diagnose: Determine why conditions in one area correspond to conditions in another
- Predict: Forecast how changing conditions in one area impact surrounding conditions
- Prescribe: Recommend actions in one area to address forecasted conditions in another area
